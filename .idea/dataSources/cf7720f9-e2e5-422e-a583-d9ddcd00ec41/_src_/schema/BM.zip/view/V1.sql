CREATE VIEW V1 AS select c1,c2
  from (select 1 as c1, date '2013-1-1' as c2 from dual
        union
        select 3 as c1, date '2014-1-1' as c2 from dual)


/
